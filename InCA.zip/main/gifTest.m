h = figure();
filename = 'Fourier Fit Evolution.gif';
load('fourierTest.mat');
cRed = [178, 24, 43]./255;
cBlue = [33, 102, 172]./255;
a = 0:1/100:1;
n = 99;
%Generate the function
[functionNameX, functionNameY] = createFourierFunc(n);
%Fit both x and y
ftx = fittype(functionNameX);
xFit = fit(transpose(1:380), X, ftx);
fty = fittype(functionNameY);
yFit = fit(transpose(1:380), Y, fty);
%Evaluate the fit
xData = feval(xFit, 0:(1/(380*n)):380);
yData = feval(yFit, 0:(1/(380*n)):380);
plot(xData, yData, 'Color', (1 - a(n)).*cRed + a(n)*cBlue, 'LineWidth', 2);
legend(num2str(n));
drawnow;
axis([150 500 200 750]);
axis equal;
frame = getframe(h);
im = frame2im(frame);
[imind, cm] = rgb2ind(im, 256);
pause(0.01);
if n == 1
    imwrite(imind, cm, filename, 'gif', 'Loopcount', Inf);
else
    imwrite(imind,cm,filename,'gif','WriteMode','append');
end
delete('xFourierFunc.m');
delete('yFourierFunc.m');
