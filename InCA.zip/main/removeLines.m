function outputPoints = removeLines(inputPoints)
[row, ~] = size(inputPoints);
intermediatePoints = [0, 0];
outputPoints = [0, 0];
%% Remove vertical lines in the data set (multiple same x values)
for r = 1:row
    %Get an x value and make sure it hasn't been used already
    xVal = inputPoints(r, 1);
    checkIndex = find(intermediatePoints(:, 1) == xVal);
    [rowCheck, ~] = size(checkIndex);
    if rowCheck > 0
        continue;
    end
    
    %Get the indicies of all the places where that x value occurs
    indicies = find(inputPoints(:, 1) == xVal);
    [rowInd, ~] = size(indicies);
    
    %If the value occurs more than once, find the min and max y value
    %associated with the x value (endpoints of the line)
    if rowInd > 2
        minVal = min(inputPoints(indicies, 2));
        maxVal = max(inputPoints(indicies, 2));
        [rowOut, ~] = size(intermediatePoints);
        intermediatePoints(rowOut + 1, :) = [xVal, minVal];
        intermediatePoints(rowOut + 2, :) = [xVal, maxVal];
        %Otherwise if it occurs only two times, assign both values
    elseif rowInd == 2
        [rowOut, ~] = size(intermediatePoints);
        intermediatePoints(rowOut + 1, :) = [xVal, inputPoints(indicies(1), 2)];
        intermediatePoints(rowOut + 2, :) = [xVal, inputPoints(indicies(2), 2)];
        %Otherwise if it only occurs once, assign that value
    elseif rowInd == 1
        [rowOut, ~] = size(intermediatePoints);
        intermediatePoints(rowOut + 1, :) = [xVal, inputPoints(indicies(1), 2)];
    end
end
%Get rid of the (0, 0) entry at the beginning
intermediatePoints = intermediatePoints(2:end, :);
%% Remove horizontal lines in the data set (multiple y values)
[row, ~] = size(intermediatePoints);
for r = 1:row
    %Get a y value and make sure it hasn't been used already
    yVal = intermediatePoints(r, 2);
    checkIndex = find(outputPoints(:, 2) == yVal);
    [rowCheck, ~] = size(checkIndex);
    if rowCheck > 0
        continue;
    end
    
    %Get the indicies of all the places where that x value occurs
    indicies = find(intermediatePoints(:, 2) == yVal);
    [rowInd, ~] = size(indicies); 
    %If the value occurs more than once, find the min and max y value
    %associated with the x value (endpoints of the line)
    if rowInd > 2
        minVal = min(intermediatePoints(indicies, 1));
        maxVal = max(intermediatePoints(indicies, 1));
        [rowOut, ~] = size(outputPoints);
        outputPoints(rowOut + 1, :) = [minVal, yVal];
        outputPoints(rowOut + 2, :) = [maxVal, yVal];
        %Otherwise if it occurs only two times, assign both values
    elseif rowInd == 2
        [rowOut, ~] = size(outputPoints);
        outputPoints(rowOut + 1, :) = [intermediatePoints(indicies(1), 1), yVal];
        outputPoints(rowOut + 2, :) = [intermediatePoints(indicies(2), 1), yVal];
        %Otherwise if it only occurs once, assign that value
    elseif rowInd == 1
        [rowOut, ~] = size(outputPoints);
        outputPoints(rowOut + 1, :) = [intermediatePoints(indicies(1), 1), yVal];
    end
end
%Get rid of the (0, 0) entry at the beginning
outputPoints = outputPoints(2:end, :);
end
