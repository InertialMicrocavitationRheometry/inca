function outputMask = reconstructBubble(inputMask)
boundary = bwboundaries(inputMask);
points = removeLines(boundary{1});
x = points(:, 1);
y = points(:, 2);
[xc, yc, R] = circfit(x, y);
[row, col] = size(inputMask);
outputMask = zeros(row, col);
[mx, my] = ndgrid(1:row, 1:col);
r = sqrt((mx - xc).^2 + (my - yc).^2);
outputMask(r <= R) = 1;
end
