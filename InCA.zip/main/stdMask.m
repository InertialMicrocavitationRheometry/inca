function stdImage = stdMask(targetImage)
[row, col] = size(targetImage);
targetImage = imgaussfilt(targetImage);
stdImage = zeros(row, col);
for r = 2:(row - 1)
    for c = 2:(col - 1)
        sampleMatrix = targetImage((r - 1):(r + 1), (c - 1):(c + 1));
        stdImage(r, c) = sqrt(var(sampleMatrix, 0, 'all'));
    end
end
%Binarize the image based on a threshold
stdImage = imfill(bwmorph(bwmorph(bwmorph(imclearborder(imcomplement(imbinarize(targetImage, graythresh(targetImage)*1.125))), 'clean'), 'diag'), 'bridge'), 'holes');
%Remove ridiculously large and small objects from the image
stdImage = removeOutliers(stdImage);
CC = bwconncomp(stdImage, 8);
if CC.NumObjects > 1
    stdImage = isolateObject(stdImage, targetImage);
end
end
