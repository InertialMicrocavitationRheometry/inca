function fileID = generateDiaryFile(logType)

currentDirectory = pwd;
idcs = strfind(currentDirectory, filesep);
if contains(currentDirectory, "main") || contains(currentDirectory, "themes") || contains(currentDirectory, "logs")
    parentDirectory = currentDirectory(1:idcs(end) - 1);
else 
    parentDirectory = currentDirectory;
end
parentDirectory = replace(parentDirectory, "\", "/");
diaryFile =  "/logs/" + logType + " " + datestr(datetime('now'));
diaryFile = replace(diaryFile, ":", "_");
fileID = fopen(parentDirectory + diaryFile + ".log", 'w');

end