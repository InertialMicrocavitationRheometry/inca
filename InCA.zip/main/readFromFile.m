function [app, fullPath] = readFromFile(app)
%% Load in the Data Table
[file, path] = uigetfile('*.mat');
fullPath = append(path, file);
load(fullPath);
%% Read in the data to the app variables
app.frames = frames;
app.mask = masks;
app.maskInformation = infoStruct;
app.ignoreFrames = ignoreFrames;
app.radius = BubbleRadius;
app.area = BubbleArea;
app.perimeter = BubblePerimeter;
app.surfaceArea = BubbleSurfaceArea;
app.centroid = BubbleCentroid;
app.volume = BubbleVolume;
app.numFrames = numFrames;
app.convertedPlotSet = alternatePlotSet;
end
